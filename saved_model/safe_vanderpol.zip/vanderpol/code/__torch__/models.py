class Safty_Dynamics(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  device : Device
  state_dim : int
  action_dim : int
  c4 : float
  f_hat : __torch__.torch.nn.modules.container.Sequential
  alpha : __torch__.torch.nn.modules.container.___torch_mangle_3.Sequential
  g : __torch__.torch.nn.modules.container.ModuleList
  def forward(self: __torch__.models.Safty_Dynamics,
    x: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    _0 = __torch__.torch.functional.___torch_mangle_5.norm
    f_hat = self.f_hat
    f_hat0 = torch.unsqueeze((f_hat).forward(x, ), 2)
    alpha = self.alpha
    alpha0 = torch.unsqueeze((alpha).forward(x, ), 2)
    _1 = annotate(List[Tensor], [])
    g = self.g
    _00 = getattr(g, "0")
    _2 = (_00).forward(x, )
    state_dim = self.state_dim
    _3 = torch.reshape(_2, [-1, state_dim, 1])
    _4 = torch.append(_1, _3)
    g0 = torch.squeeze(torch.stack(_1, 2), 3)
    eta = torch.reshape(__torch__.eta(x, ), [-1, 1, 1])
    torch.autograd.backward(torch.sum(eta), None, True)
    grad_eta = torch.unsqueeze(ops.prim.grad(x), 2)
    _5 = torch.transpose(grad_eta, 1, 2)
    _6 = torch.add(f_hat0, torch.matmul(g0, alpha0))
    _7 = torch.matmul(_5, _6)
    c4 = self.c4
    criterion = torch.add(_7, torch.mul(eta, c4))
    _8 = torch.neg(criterion)
    _9 = _0(grad_eta, 2, 1, True, None, None, )
    _10 = torch.add(torch.pow(_9, 2), 9.9999999999999995e-07)
    f_eta = torch.mul(torch.div(_8, _10), grad_eta)
    mask = torch.le(criterion, 0)
    f = torch.where(mask, f_hat0, torch.add(f_hat0, f_eta))
    return (f, g0, alpha0)
