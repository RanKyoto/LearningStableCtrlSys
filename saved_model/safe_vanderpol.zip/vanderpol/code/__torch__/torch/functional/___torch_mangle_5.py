def norm(input: Tensor,
    p: Optional[number],
    dim: Optional[int]=None,
    keepdim: bool=False,
    out: Optional[Tensor]=None,
    dtype: Optional[int]=None) -> Tensor:
  if torch.eq(ops.prim.layout(input), 0):
    _1 = ops.prim.type(ops.prim.device(input))
    _2 = ["cpu", "cuda", "meta", "privateuseone"]
    _0 = torch.__contains__(_2, _1)
  else:
    _0 = False
  if _0:
    if torch.__isnot__(dim, None):
      dim0 = unchecked_cast(int, dim)
      dim1 = unchecked_cast(int, dim0)
      _dim : Optional[List[int]] = [dim1]
    else:
      _dim = None
    p0 = unchecked_cast(Optional[number], p)
    if torch.__is__(p0, None):
      _p = 2.
    else:
      _p = unchecked_cast(number, p0)
    if torch.__is__(out, None):
      _5 = torch.linalg_vector_norm(input, _p, _dim, keepdim, dtype=dtype)
      _4 = _5
    else:
      out0 = unchecked_cast(Tensor, out)
      _6 = torch.linalg_vector_norm(input, _p, _dim, keepdim, dtype=dtype, out=out0)
      _4 = _6
    _3 = _4
  else:
    ndim = torch.dim(input)
    if torch.__is__(dim, None):
      _7, dim2 = torch.__is__(out, None), dim
    else:
      _7, dim2 = False, unchecked_cast(int, dim)
    if _7:
      _8 = torch.__is__(dtype, None)
    else:
      _8 = False
    if _8:
      _9 = torch.__isnot__(p, None)
    else:
      _9 = False
    if _9:
      p1 = unchecked_cast(number, p)
      p2 = unchecked_cast(Union[number], p1)
      p3 = unchecked_cast(Union[number], p2)
      _dim0 = annotate(List[int], [])
      for i in range(ndim):
        _11 = torch.append(_dim0, i)
      _12 = torch.norm(input, p3, _dim0, keepdim)
      _10 = _12
    else:
      if torch.__isnot__(dim2, None):
        dim3 = unchecked_cast(int, dim2)
        dim4 = unchecked_cast(int, dim3)
        _dim1 : Optional[List[int]] = [dim4]
      else:
        _dim1 = None
      p4 = unchecked_cast(Optional[number], p)
      if torch.__is__(_dim1, None):
        _dim3 = annotate(List[int], [])
        for _13 in range(ndim):
          _14 = torch.append(_dim3, _13)
        _dim2 = _dim3
      else:
        _dim4 = unchecked_cast(List[int], _dim1)
        _dim2 = _dim4
      if torch.__is__(out, None):
        if torch.__is__(dtype, None):
          _17 = torch.norm(input, p4, _dim2, keepdim)
          _16 = _17
        else:
          dtype0 = unchecked_cast(int, dtype)
          _18 = torch.norm(input, p4, _dim2, keepdim, dtype=dtype0)
          _16 = _18
        _15 = _16
      else:
        out1 = unchecked_cast(Tensor, out)
        if torch.__is__(dtype, None):
          _20 = torch.norm(input, p4, _dim2, keepdim, out=out1)
          _19 = _20
        else:
          dtype1 = unchecked_cast(int, dtype)
          _21 = torch.norm(input, p4, _dim2, keepdim, dtype=dtype1, out=out1)
          _19 = _21
        _15 = _19
      _10 = _15
    _3 = _10
  return _3
