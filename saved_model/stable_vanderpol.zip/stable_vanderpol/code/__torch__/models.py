class Stable_Dynamics(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  device : Device
  state_dim : int
  action_dim : int
  x_stable : Tensor
  f_hat : __torch__.torch.nn.modules.container.Sequential
  lyapunov_function : __torch__.networks.LyapunovFunction
  alpha_hat : __torch__.torch.nn.modules.container.___torch_mangle_6.Sequential
  g : __torch__.torch.nn.modules.container.___torch_mangle_7.ModuleList
  def forward(self: __torch__.models.Stable_Dynamics,
    x: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor]:
    _0 = __torch__.torch.functional.___torch_mangle_9.norm
    f_hat = self.f_hat
    _1 = (f_hat).forward(x, )
    f_hat0 = self.f_hat
    x_stable = self.x_stable
    _2 = torch.sub(_1, (f_hat0).forward(x_stable, ))
    f0 = torch.unsqueeze(_2, 2)
    alpha_hat = self.alpha_hat
    _3 = (alpha_hat).forward(x, )
    alpha_hat0 = self.alpha_hat
    x_stable0 = self.x_stable
    _4 = torch.sub(_3, (alpha_hat0).forward(x_stable0, ))
    alpha = torch.unsqueeze(_4, 2)
    _5 = annotate(List[Tensor], [])
    g = self.g
    _00 = getattr(g, "0")
    _6 = (_00).forward(x, )
    state_dim = self.state_dim
    _7 = torch.reshape(_6, [-1, state_dim, 1])
    _8 = torch.append(_5, _7)
    g0 = torch.squeeze(torch.stack(_5, 2), 3)
    lyapunov_function = self.lyapunov_function
    V = (lyapunov_function).forward(x, )
    torch.autograd.backward(torch.sum(V))
    grad_V = torch.unsqueeze(ops.prim.grad(x), 2)
    _9 = _0(torch.unsqueeze(x, 2), 2, 1, True, None, None, )
    W = torch.mul(torch.pow(_9, 2), 0.10000000000000001)
    _10 = torch.transpose(grad_V, 1, 2)
    _11 = torch.add(f0, torch.matmul(g0, alpha))
    criterion = torch.add(torch.matmul(_10, _11), W)
    _12 = torch.neg(criterion)
    _13 = _0(grad_V, 2, 1, True, None, None, )
    _14 = torch.add(torch.pow(_13, 2), 9.9999999999999995e-07)
    fs = torch.mul(torch.div(_12, _14), grad_V)
    mask = torch.le(criterion, 0)
    f = torch.where(mask, f0, torch.add(f0, fs))
    return (f, g0, alpha, V)
