class LyapunovFunction(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  input_dim : int
  x_stable : Tensor
  eps : float
  icnn : __torch__.networks.ICNN
  def forward(self: __torch__.networks.LyapunovFunction,
    x: Tensor) -> Tensor:
    icnn = self.icnn
    eta_x = (icnn).forward(x, )
    icnn0 = self.icnn
    x_stable = self.x_stable
    eta_0 = (icnn0).forward(x_stable, )
    _0 = __torch__.torch.nn.functional.relu(torch.sub(eta_x, eta_0), False, )
    eps = self.eps
    x_stable0 = self.x_stable
    _1 = torch.pow(torch.sub(x, x_stable0), 2)
    _2 = torch.mul(torch.sum(_1, [1], True), eps)
    return torch.add(_0, _2)
class ICNN(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  net_arch : List[int]
  activation_fn : __torch__.utils.SmoothReLU
  Wx_layers : __torch__.torch.nn.modules.container.ModuleList
  Uz_layers : __torch__.torch.nn.modules.container.___torch_mangle_4.ModuleList
  def forward(self: __torch__.networks.ICNN,
    x: Tensor) -> Tensor:
    tmp_Wx = annotate(List[Tensor], [])
    Wx_layers = self.Wx_layers
    _0 = getattr(Wx_layers, "0")
    _1 = getattr(Wx_layers, "1")
    _2 = getattr(Wx_layers, "2")
    _3 = torch.append(tmp_Wx, (_0).forward(x, ))
    _4 = torch.append(tmp_Wx, (_1).forward(x, ))
    _5 = torch.append(tmp_Wx, (_2).forward(x, ))
    activation_fn = self.activation_fn
    zi = (activation_fn).forward(tmp_Wx[0], )
    Uz_layers = self.Uz_layers
    _00 = getattr(Uz_layers, "0")
    _10 = getattr(Uz_layers, "1")
    zi0 = torch.add(tmp_Wx[1], (_00).forward(zi, ))
    activation_fn0 = self.activation_fn
    zi1 = (activation_fn0).forward(zi0, )
    zi2 = torch.add(tmp_Wx[2], (_10).forward(zi1, ))
    activation_fn1 = self.activation_fn
    return (activation_fn1).forward(zi2, )
class posLinear(Module):
  __parameters__ = ["weight", "bias", ]
  __buffers__ = []
  weight : Tensor
  bias : NoneType
  training : bool
  _is_full_backward_hook : NoneType
  in_features : Final[int] = 32
  out_features : Final[int] = 32
  def forward(self: __torch__.networks.posLinear,
    input: Tensor) -> Tensor:
    weight = self.weight
    positive_weight = torch.softplus(torch.div(weight, 32))
    bias = self.bias
    _6 = torch.linear(input, positive_weight, bias)
    return _6
